﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace BrowserOpenSourceProject
{
    public partial class Web : Form
    {
        public Web()
        {
            InitializeComponent();
        }

        private void back_Click(object sender, EventArgs e)
        {
            if (webView != null && webView.CoreWebView2 != null && webView.CoreWebView2.CanGoBack)
            {
                webView.CoreWebView2.GoBack();
            }
        }

        private void forward_Click(object sender, EventArgs e)
        {
            if (webView != null && webView.CoreWebView2 != null && webView.CoreWebView2.CanGoForward)
            {
                webView.CoreWebView2.GoForward();
            }
        }

        private void reload_Click(object sender, EventArgs e)
        {
            if (webView != null && webView.CoreWebView2 != null)
            {
                webView.CoreWebView2.Reload();
            }
        }

        private void search_Click(object sender, EventArgs e)
        {
            if (addressBar.Text != "" && addressBar.Text != " ")
            {
                if (webView != null && webView.CoreWebView2 != null)
                {
                    try
                    {
                        // Control if URL starts with https://www. or http://www.
                        if (!addressBar.Text.StartsWith("https://www.") && !addressBar.Text.StartsWith("http://www.") && !addressBar.Text.StartsWith("https://") && !addressBar.Text.StartsWith("http://"))
                        {
                            addressBar.Text = "https://www." + addressBar.Text;
                        }

                        webView.CoreWebView2.Navigate(addressBar.Text);
                    }
                    catch (Exception ex)
                    {
                        // Handle potential navigation errors gracefully
                        MessageBox.Show("An error occurred while navigating: " + ex.Message, "Navigation Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
    }
}
